# Load necessary libraries
library(ggplot2)

# Hard-coded dataset
data <- data.frame(
  Month = c("January", "February", "March", "April", "May", "June"),
  Sales = c(150, 200, 250, 300, 350, 400),
  Profit = c(30, 50, 80, 90, 100, 120)
)

# Display the dataset
print(data)

# Bar graph for Sales
ggplot(data, aes(x = Month, y = Sales)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  labs(title = "Monthly Sales", x = "Month", y = "Sales") +
  theme_minimal()

# Line graph for Profit
ggplot(data, aes(x = Month, y = Profit)) +
  geom_line(color = "red", size = 1) +
  geom_point(color = "red", size = 3) +
  labs(title = "Monthly Profit", x = "Month", y = "Profit") +
  theme_minimal()

# Scatter plot for Sales vs Profit
ggplot(data, aes(x = Sales, y = Profit)) +
  geom_point(color = "green", size = 3) +
  labs(title = "Sales vs Profit", x = "Sales", y = "Profit") +
  theme_minimal()